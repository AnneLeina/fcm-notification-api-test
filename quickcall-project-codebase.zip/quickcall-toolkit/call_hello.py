import requests
import os
from dotenv import load_dotenv

# Load credentials from .env file
load_dotenv()

API_KEY = os.getenv("QUICKCALL_API_KEY")
API_SECRET = os.getenv("QUICKCALL_API_SECRET")
FROM_NUMBER = os.getenv("QUICKCALL_FROM_NUMBER")

# API endpoint for outbound calls
url = "https://api.quickcall.io/v1/calls/outbound"

# Request payload
payload = {
    "to": "+254712345678",        # Recipient phone number (E.164 format)
    "from": FROM_NUMBER,          # Your Quickcall number
    "tts_message": "Hello! This is a test call from the Quickcall API. Your toolkit is working correctly.",
    "tts_language": "en-KE",      # English, Kenya locale
    "record": False               # Set True to record the call
}

# Authentication headers
headers = {
    "Content-Type": "application/json",
    "X-API-Key": API_KEY,
    "X-API-Secret": API_SECRET
}

# Make the API call
response = requests.post(url, json=payload, headers=headers)

# Handle the response
if response.status_code == 200:
    data = response.json()
    print("✅ Call initiated successfully!")
    print(f"   Call ID   : {data['call_id']}")
    print(f"   Status    : {data['status']}")
    print(f"   To        : {data['to']}")
    print(f"   Duration  : {data.get('estimated_duration', 'N/A')} seconds")
else:
    print(f"❌ Error {response.status_code}: {response.text}")
