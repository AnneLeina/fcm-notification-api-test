import requests
import os
from dotenv import load_dotenv

load_dotenv()

CALL_ID = "qc_abc123def456"   # Replace with your actual Call ID

url = f"https://api.quickcall.io/v1/calls/{CALL_ID}/status"

headers = {
    "X-API-Key": os.getenv("QUICKCALL_API_KEY"),
    "X-API-Secret": os.getenv("QUICKCALL_API_SECRET")
}

response = requests.get(url, headers=headers)

if response.status_code == 200:
    data = response.json()
    print(f"📞 Call Status Report")
    print(f"   Call ID    : {data['call_id']}")
    print(f"   Status     : {data['status']}")
    print(f"   Duration   : {data.get('duration', 0)} seconds")
    print(f"   Cost       : {data.get('cost', 'N/A')} credits")
else:
    print(f"❌ Error: {response.text}")
