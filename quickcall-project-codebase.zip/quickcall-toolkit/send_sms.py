import requests
import os
from dotenv import load_dotenv

load_dotenv()

url = "https://api.quickcall.io/v1/sms/send"

payload = {
    "to": "+254712345678",
    "from": "QuickKit",               # Sender ID or number
    "message": "Hello from Quickcall! Your beginner toolkit is up and running. 🎉"
}

headers = {
    "Content-Type": "application/json",
    "X-API-Key": os.getenv("QUICKCALL_API_KEY"),
    "X-API-Secret": os.getenv("QUICKCALL_API_SECRET")
}

response = requests.post(url, json=payload, headers=headers)

if response.status_code == 200:
    data = response.json()
    print("✅ SMS sent successfully!")
    print(f"   Message ID : {data['message_id']}")
    print(f"   Status     : {data['status']}")
else:
    print(f"❌ Failed: {response.text}")
