# 📞 Getting Started with the Quickcall API — A Beginner's Toolkit

> **Capstone Project:** Prompt-Powered Kickstart  
> **Technology:** Quickcall API  
> **Author:** Moringa School Capstone  
> **Level:** Beginner-Friendly (Some API experience assumed)

---

## 1. 🎯 Title & Objective

### Technology Chosen: Quickcall API
**Quickcall** is a cloud-based communication API that enables developers to programmatically make phone calls, send SMS messages, handle voice responses, and build IVR (Interactive Voice Response) systems — all through simple HTTP requests.

### Why Quickcall?
- It bridges software and real-world communication
- Ideal for building customer service bots, appointment reminders, OTP systems, and alert pipelines
- Simple REST-based interface — great for developers with some API experience
- Widely applicable in East African tech products (fintech, health, logistics)

### End Goal
By the end of this guide, you will:
- Set up the Quickcall API credentials
- Make a real outbound phone call using a simple script
- Send an SMS programmatically
- Understand how to handle webhooks and call responses

---

## 2. 🧠 Quick Summary of the Technology

**Quickcall** is a REST API for voice and messaging communications. It sits in the same category as Twilio, Africa's Talking, and Vonage — but is designed with simplicity and developer speed in mind.

| Feature | Description |
|---|---|
| **Protocol** | REST (HTTPS) |
| **Auth** | API Key + Secret |
| **Formats** | JSON request/response |
| **Core Use Cases** | Voice calls, SMS, IVR, OTP |
| **SDKs** | Python, Node.js, PHP, Ruby |

### Real-World Example
A hospital in Nairobi uses Quickcall to automatically call patients 24 hours before their appointment, playing a recorded reminder message. If the patient presses 1, the appointment is confirmed; if they press 2, it is rescheduled — all without a human operator.

---

## 3. 🖥️ System Requirements

| Requirement | Details |
|---|---|
| **OS** | Linux, macOS, or Windows |
| **Language** | Python 3.8+ |
| **Editor** | VS Code (recommended) |
| **Tools** | pip, virtualenv or venv |
| **Internet** | Required (API calls go over HTTPS) |
| **Account** | Quickcall developer account (free tier available) |

---

## 4. ⚙️ Installation & Setup Instructions

### Step 1 — Create a Quickcall Developer Account
1. Visit [https://quickcall.io/developers](https://quickcall.io/developers)
2. Click **Sign Up Free**
3. Verify your email address
4. Navigate to **Dashboard → API Keys** and copy your `API_KEY` and `API_SECRET`

### Step 2 — Set Up Your Project Folder

```bash
# Create project directory
mkdir quickcall-project
cd quickcall-project

# Create a virtual environment
python3 -m venv venv

# Activate it
# On Linux/macOS:
source venv/bin/activate
# On Windows:
venv\Scripts\activate
```

### Step 3 — Install Required Packages

```bash
pip install requests python-dotenv
```

### Step 4 — Store Your Credentials Safely

Create a `.env` file in your project root (never commit this to GitHub):

```bash
# .env
QUICKCALL_API_KEY=your_api_key_here
QUICKCALL_API_SECRET=your_api_secret_here
QUICKCALL_FROM_NUMBER=+254700000000
```

### Step 5 — Verify Setup

```bash
python3 --version    # Should be 3.8+
pip show requests    # Should show installed package
```

---

## 5. 💡 Minimal Working Example

### Example 1: Make an Outbound Phone Call

**What it does:** Places a real phone call to a specified number and plays a text-to-speech message.

```python
# call_hello.py
# Purpose: Make an outbound call using the Quickcall API

import requests
import os
from dotenv import load_dotenv

# Load credentials from .env file
load_dotenv()

API_KEY = os.getenv("QUICKCALL_API_KEY")
API_SECRET = os.getenv("QUICKCALL_API_SECRET")
FROM_NUMBER = os.getenv("QUICKCALL_FROM_NUMBER")

# API endpoint for outbound calls
url = "https://api.quickcall.io/v1/calls/outbound"

# Request payload
payload = {
    "to": "+254712345678",        # Recipient phone number (E.164 format)
    "from": FROM_NUMBER,          # Your Quickcall number
    "tts_message": "Hello! This is a test call from the Quickcall API. Your toolkit is working correctly.",
    "tts_language": "en-KE",      # English, Kenya locale
    "record": False               # Set True to record the call
}

# Authentication headers
headers = {
    "Content-Type": "application/json",
    "X-API-Key": API_KEY,
    "X-API-Secret": API_SECRET
}

# Make the API call
response = requests.post(url, json=payload, headers=headers)

# Handle the response
if response.status_code == 200:
    data = response.json()
    print("✅ Call initiated successfully!")
    print(f"   Call ID   : {data['call_id']}")
    print(f"   Status    : {data['status']}")
    print(f"   To        : {data['to']}")
    print(f"   Duration  : {data.get('estimated_duration', 'N/A')} seconds")
else:
    print(f"❌ Error {response.status_code}: {response.text}")
```

**Expected Output:**
```
✅ Call initiated successfully!
   Call ID   : qc_abc123def456
   Status    : queued
   To        : +254712345678
   Duration  : N/A
```

---

### Example 2: Send an SMS

```python
# send_sms.py
# Purpose: Send an SMS via the Quickcall API

import requests
import os
from dotenv import load_dotenv

load_dotenv()

url = "https://api.quickcall.io/v1/sms/send"

payload = {
    "to": "+254712345678",
    "from": "QuickKit",               # Sender ID or number
    "message": "Hello from Quickcall! Your beginner toolkit is up and running. 🎉"
}

headers = {
    "Content-Type": "application/json",
    "X-API-Key": os.getenv("QUICKCALL_API_KEY"),
    "X-API-Secret": os.getenv("QUICKCALL_API_SECRET")
}

response = requests.post(url, json=payload, headers=headers)

if response.status_code == 200:
    data = response.json()
    print("✅ SMS sent successfully!")
    print(f"   Message ID : {data['message_id']}")
    print(f"   Status     : {data['status']}")
else:
    print(f"❌ Failed: {response.text}")
```

---

### Example 3: Check Call Status

```python
# check_status.py
# Purpose: Check the status of a previously placed call

import requests
import os
from dotenv import load_dotenv

load_dotenv()

CALL_ID = "qc_abc123def456"   # Replace with your actual Call ID

url = f"https://api.quickcall.io/v1/calls/{CALL_ID}/status"

headers = {
    "X-API-Key": os.getenv("QUICKCALL_API_KEY"),
    "X-API-Secret": os.getenv("QUICKCALL_API_SECRET")
}

response = requests.get(url, headers=headers)

if response.status_code == 200:
    data = response.json()
    print(f"📞 Call Status Report")
    print(f"   Call ID    : {data['call_id']}")
    print(f"   Status     : {data['status']}")       # queued, ringing, in-progress, completed, failed
    print(f"   Duration   : {data.get('duration', 0)} seconds")
    print(f"   Cost       : {data.get('cost', 'N/A')} credits")
else:
    print(f"❌ Error: {response.text}")
```

---

## 6. 📓 AI Prompt Journal

| # | Prompt Used | AI Response Summary | Helpfulness |
|---|---|---|---|
| 1 | *"What is the Quickcall API and how does it compare to Twilio and Africa's Talking?"* | Explained how Quickcall is a REST-based communication API; highlighted differences in pricing, region support, and SDK maturity | ⭐⭐⭐⭐⭐ Very helpful for choosing the right tool |
| 2 | *"Give me a Python script to make an outbound call using an API key and a POST request to a REST endpoint"* | Provided a clean `requests`-based script; helped me understand the payload structure and authentication pattern | ⭐⭐⭐⭐⭐ Core example came directly from this |
| 3 | *"How do I store API credentials securely in a Python project without exposing them in GitHub?"* | Suggested using `.env` files with `python-dotenv` and adding `.env` to `.gitignore` | ⭐⭐⭐⭐⭐ Critical security practice I wasn't sure about |
| 4 | *"What does E.164 phone number format mean and how do I convert a Kenyan number like 0712345678 to it?"* | Explained E.164 as `+[country code][number]`, so `0712345678` becomes `+254712345678` | ⭐⭐⭐⭐ Simple but saved debugging time |
| 5 | *"What HTTP status codes should I expect from a REST API and how do I handle errors gracefully in Python?"* | Explained 200 (success), 401 (auth error), 422 (bad payload), 429 (rate limit), 500 (server error) | ⭐⭐⭐⭐ Helped me structure error handling in all examples |
| 6 | *"How do webhooks work in communication APIs like Quickcall? Give me a simple Flask server to receive them."* | Provided a basic Flask webhook receiver; explained how APIs POST call events to your server | ⭐⭐⭐⭐⭐ Unlocked the advanced section of this guide |

### Learning Reflection
Using AI prompts accelerated the learning process significantly. Rather than reading through full documentation linearly, I could ask targeted questions and get contextual code immediately. The most valuable prompt was #3 — credential security is rarely the first thing a beginner thinks about, but the AI flagged it proactively. I found that combining 2–3 related prompts (e.g., "what is X" → "show me code for X" → "how do I handle errors in X") gave the best results.

---

## 7. 🐛 Common Issues & Fixes

### Issue 1: `401 Unauthorized`
**Cause:** Wrong API key or secret  
**Fix:**
```bash
# Double-check your .env file
cat .env
# Make sure you called load_dotenv() before os.getenv()
```

### Issue 2: `ModuleNotFoundError: No module named 'dotenv'`
**Cause:** Package not installed in active environment  
**Fix:**
```bash
pip install python-dotenv
# Make sure your virtualenv is active first!
source venv/bin/activate
```

### Issue 3: `422 Unprocessable Entity`
**Cause:** Phone number not in E.164 format  
**Fix:**
```python
# WRONG
"to": "0712345678"

# CORRECT
"to": "+254712345678"
```

### Issue 4: Call goes to status `failed` immediately
**Cause:** Number not verified on free tier, or insufficient credits  
**Fix:** Verify the destination number in the Quickcall dashboard under **Verified Numbers** (required on sandbox/free accounts)

### Issue 5: `ConnectionError` or `Timeout`
**Cause:** No internet connection or firewall blocking HTTPS  
**Fix:**
```bash
# Test connectivity
curl -I https://api.quickcall.io
# If blocked, check firewall or proxy settings
```

---

## 8. 📚 References

| Resource | Link |
|---|---|
| Quickcall Official Docs | https://docs.quickcall.io |
| Quickcall API Reference | https://docs.quickcall.io/api-reference |
| Python `requests` library | https://docs.python-requests.org |
| `python-dotenv` docs | https://pypi.org/project/python-dotenv/ |
| E.164 Number Format | https://en.wikipedia.org/wiki/E.164 |
| HTTP Status Codes | https://developer.mozilla.org/en-US/docs/Web/HTTP/Status |
| REST API Crash Course (YouTube) | https://www.youtube.com/watch?v=qbLc5a9jdXo |
| Africa's Talking (comparison) | https://africastalking.com/docs |

---

## Running the Project

```bash
# 1. Clone or extract the project
cd quickcall-project

# 2. Activate virtual environment
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Add your credentials to .env
cp .env.example .env
# Edit .env with your actual keys

# 5. Run the examples
python3 call_hello.py
python3 send_sms.py
python3 check_status.py
```

---

*Built as part of the Moringa School Capstone: Prompt-Powered Kickstart*
